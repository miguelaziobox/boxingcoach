/* ── DATA ── */
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DNAMES = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const CIRC = 2 * Math.PI * 50;

const PUNCH_DATA = {
  jab:      { label: 'Jab',      chip: 'chip-jab',      word: 'JAB!',    freq: 320, type: 'square',   vol: 0.18, dur: 0.07, freqEnd: 130 },
  cross:    { label: 'Cross',    chip: 'chip-cross',    word: 'CROSS!',  freq: 240, type: 'square',   vol: 0.22, dur: 0.10, freqEnd: 95  },
  hook:     { label: 'Hook',     chip: 'chip-hook',     word: 'HOOK!',   freq: 200, type: 'sawtooth', vol: 0.24, dur: 0.13, freqEnd: 80  },
  uppercut: { label: 'Uppercut', chip: 'chip-uppercut', word: 'UPPER!',  freq: 160, type: 'sawtooth', vol: 0.26, dur: 0.08, freqEnd: 260 },
  body:     { label: 'Body',     chip: 'chip-body',     word: 'BODY!',   freq: 180, type: 'square',   vol: 0.20, dur: 0.10, freqEnd: 70  },
  slip:     { label: 'Slip',     chip: 'chip-slip',     word: 'SLIP!',   freq: 900, type: 'sine',     vol: 0.12, dur: 0.15, freqEnd: 600 },
};

const COMBOS = [
  { name: 'Jab–Cross (1–2)',         punches: ['jab','cross'] },
  { name: 'Jab–Cross–Hook (1–2–3)',  punches: ['jab','cross','hook'] },
  { name: 'Double Jab–Cross',        punches: ['jab','jab','cross'] },
  { name: '1–2–3–2',                 punches: ['jab','cross','hook','cross'] },
  { name: 'Slip–Cross–Hook',         punches: ['slip','cross','hook'] },
  { name: 'Body–Head Jab',           punches: ['body','jab'] },
  { name: 'Jab–Uppercut–Cross',      punches: ['jab','uppercut','cross'] },
  { name: 'Cross–Hook–Cross',        punches: ['cross','hook','cross'] },
  { name: 'Jab–Cross–Body Hook',     punches: ['jab','cross','body'] },
  { name: 'Slip–Uppercut–Hook',      punches: ['slip','uppercut','hook'] },
];

const PHASE_META = {
  warmup:   { label: 'Warm-up',   cls: 'eph-warmup',   color: '#BA7517' },
  boxing:   { label: 'Boxing',    cls: 'eph-boxing',   color: '#E24B4A' },
  strength: { label: 'Strength',  cls: 'eph-strength', color: '#185FA5' },
  core:     { label: 'Core',      cls: 'eph-core',     color: '#639922' },
  cooldown: { label: 'Cool-down', cls: 'eph-cooldown', color: '#0F6E56' },
  rest:     { label: 'Rest',      cls: 'eph-rest',     color: '#888780' },
};

const WORKOUTS = {
  A: { label: 'Day A – Power', pill: 'pa', color: '#E24B4A', exercises: [
    { name: 'Jump rope',                    phase: 'warmup',   secs: 180, rounds: 1, detail: 'Light pace, stay on toes' },
    { name: 'Arm circles + shoulder rolls', phase: 'warmup',   secs: 60,  rounds: 1, detail: 'Full ROM' },
    { name: 'Hip rotations + leg swings',   phase: 'warmup',   secs: 60,  rounds: 1, detail: 'Both sides' },
    { name: 'Shadowboxing – footwork',      phase: 'warmup',   secs: 120, rounds: 1, detail: 'Move & pivot' },
    { name: 'Rest',                         phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Shadowboxing – 1-2-3 combos', phase: 'boxing',   secs: 180, rounds: 3, detail: 'Jab–Cross–Hook' },
    { name: 'Rest between rounds',          phase: 'rest',     secs: 60,  rounds: 1, detail: '' },
    { name: 'Heavy bag – power shots',      phase: 'boxing',   secs: 180, rounds: 3, detail: 'Max power crosses & hooks' },
    { name: 'Rest between rounds',          phase: 'rest',     secs: 60,  rounds: 1, detail: '' },
    { name: 'Push-ups',                     phase: 'strength', secs: 45,  rounds: 3, detail: '12–15 reps' },
    { name: 'Rest',                         phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Bodyweight squats',            phase: 'strength', secs: 45,  rounds: 3, detail: '15 reps, drive through heels' },
    { name: 'Rest',                         phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Plank',                        phase: 'core',     secs: 45,  rounds: 3, detail: 'Tight core, level hips' },
    { name: 'Rest',                         phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Mountain climbers',            phase: 'core',     secs: 40,  rounds: 2, detail: 'Fast knees' },
    { name: 'Rest',                         phase: 'rest',     secs: 20,  rounds: 1, detail: '' },
    { name: 'Cool-down stretch',            phase: 'cooldown', secs: 240, rounds: 1, detail: 'Full body stretch' },
  ]},
  B: { label: 'Day B – Speed', pill: 'pb', color: '#185FA5', exercises: [
    { name: 'Jump rope – fast singles',     phase: 'warmup',   secs: 180, rounds: 1, detail: 'Build up pace' },
    { name: 'Neck & wrist mobilisation',    phase: 'warmup',   secs: 60,  rounds: 1, detail: '' },
    { name: 'Torso twists',                 phase: 'warmup',   secs: 60,  rounds: 1, detail: 'Loose and fluid' },
    { name: 'Shadowboxing – slips & rolls', phase: 'warmup',   secs: 120, rounds: 1, detail: 'Defence focus' },
    { name: 'Rest',                         phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Speed target – rapid jabs',    phase: 'boxing',   secs: 120, rounds: 4, detail: 'Max hand speed' },
    { name: 'Rest between rounds',          phase: 'rest',     secs: 45,  rounds: 1, detail: '' },
    { name: 'Shadowboxing – full combos',   phase: 'boxing',   secs: 180, rounds: 3, detail: 'Use all 4 punches' },
    { name: 'Rest between rounds',          phase: 'rest',     secs: 60,  rounds: 1, detail: '' },
    { name: 'Burpees',                      phase: 'strength', secs: 40,  rounds: 3, detail: '8–10 reps, explosive' },
    { name: 'Rest',                         phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Walking lunges',               phase: 'strength', secs: 45,  rounds: 3, detail: '12 each leg' },
    { name: 'Rest',                         phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'V-sits',                       phase: 'core',     secs: 40,  rounds: 3, detail: '15 reps controlled' },
    { name: 'Rest',                         phase: 'rest',     secs: 20,  rounds: 1, detail: '' },
    { name: 'Russian twists',               phase: 'core',     secs: 40,  rounds: 3, detail: 'Rotate fully each side' },
    { name: 'Rest',                         phase: 'rest',     secs: 20,  rounds: 1, detail: '' },
    { name: 'Cool-down stretch',            phase: 'cooldown', secs: 240, rounds: 1, detail: 'Full body stretch' },
  ]},
  C: { label: 'Day C – Conditioning', pill: 'pc', color: '#639922', exercises: [
    { name: 'Jump rope – double unders',         phase: 'warmup',   secs: 180, rounds: 1, detail: 'Mix singles and doubles' },
    { name: 'Dynamic stretching',                phase: 'warmup',   secs: 90,  rounds: 1, detail: 'Leg swings, arm crosses' },
    { name: 'Shadowboxing – defensive',          phase: 'warmup',   secs: 120, rounds: 1, detail: 'Slip, roll, pivot focus' },
    { name: 'Rest',                              phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'HIIT – 10-punch burst + squat',    phase: 'boxing',   secs: 180, rounds: 4, detail: 'All-out 10 punches then squat' },
    { name: 'Rest between rounds',               phase: 'rest',     secs: 60,  rounds: 1, detail: '' },
    { name: 'Heavy bag – body shots',            phase: 'boxing',   secs: 180, rounds: 3, detail: 'Liver & solar plexus hooks' },
    { name: 'Rest between rounds',               phase: 'rest',     secs: 60,  rounds: 1, detail: '' },
    { name: 'Diamond push-ups',                  phase: 'strength', secs: 45,  rounds: 3, detail: '10–12 reps' },
    { name: 'Rest',                              phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Jump squats',                       phase: 'strength', secs: 40,  rounds: 3, detail: 'Explosive, land soft' },
    { name: 'Rest',                              phase: 'rest',     secs: 30,  rounds: 1, detail: '' },
    { name: 'Hollow body hold',                  phase: 'core',     secs: 40,  rounds: 3, detail: 'Lower back pressed down' },
    { name: 'Rest',                              phase: 'rest',     secs: 20,  rounds: 1, detail: '' },
    { name: 'Bicycle crunches',                  phase: 'core',     secs: 45,  rounds: 3, detail: 'Slow and controlled' },
    { name: 'Rest',                              phase: 'rest',     secs: 20,  rounds: 1, detail: '' },
    { name: 'Cool-down stretch',                 phase: 'cooldown', secs: 300, rounds: 1, detail: 'Full body stretch' },
  ]},
};

/* ── STATE ── */
const today = new Date();
let viewYear = today.getFullYear();
let viewMonth = today.getMonth();
let selectedCalDay = null;
let completed = {};
let workoutDays = [1, 3, 5]; // Mon, Wed, Fri
let dayOrder = ['A', 'B', 'C'];

let tActiveDay = 'A';
let tActiveEx = 0;
let tRunning = false;
let tInterval = null;
let tRemaining = 0;
let tRound = 1;
let comboSeqId = null;
let currentCombo = null;
let audioCtx = null;

/* ── AUDIO ── */
function ensureAudio() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
}

function playTone(freq, type, vol, dur, freqEnd) {
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.connect(g); g.connect(audioCtx.destination);
  o.type = type;
  o.frequency.setValueAtTime(freq, audioCtx.currentTime);
  if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd, audioCtx.currentTime + dur);
  g.gain.setValueAtTime(vol, audioCtx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + dur);
  o.start(); o.stop(audioCtx.currentTime + dur + 0.05);
}

function playPunch(key) {
  const p = PUNCH_DATA[key];
  playTone(p.freq, p.type, p.vol, p.dur, p.freqEnd);
  if (key === 'uppercut') setTimeout(() => playTone(260, 'square', 0.18, 0.07, 100), 90);
}

function playBell()    { playTone(880, 'sine', 0.3, 0.8); }
function playWhistle() { playTone(1500, 'sine', 0.2, 0.25, 1100); }

/* ── HELPERS ── */
function fmt(s) {
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}
function dayKey(y, m, d) { return y + '-' + m + '-' + d; }

function getWorkoutForDate(y, m, d) {
  const dow = new Date(y, m, d).getDay();
  const idx = workoutDays.indexOf(dow);
  if (idx === -1) return 'R';
  return dayOrder[idx % dayOrder.length] || 'R';
}

/* ── NAVIGATION ── */
function showView(v) {
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  document.getElementById('view-' + v).classList.add('active');
  const idx = { calendar: 0, timer: 1, settings: 2 }[v];
  document.querySelectorAll('.tab')[idx].classList.add('active');
  if (v === 'calendar') buildCalendar();
  if (v === 'timer') { buildTimerTabs(); renderExList(); loadEx(); }
  if (v === 'settings') buildSettings();
}

/* ── CALENDAR ── */
function buildCalendar() {
  const y = viewYear, mo = viewMonth;
  document.getElementById('calTitle').textContent = MONTHS[mo] + ' ' + y;
  document.getElementById('dhRow').innerHTML = DNAMES.map(d => `<div class="dh">${d}</div>`).join('');

  const firstDay = new Date(y, mo, 1).getDay();
  const dim = new Date(y, mo + 1, 0).getDate();
  let sess = 0, done = 0, streak = 0;
  let html = '';

  for (let i = 0; i < firstDay; i++) html += `<div class="dc empty"></div>`;

  for (let d = 1; d <= dim; d++) {
    const wt = getWorkoutForDate(y, mo, d);
    const dk = dayKey(y, mo, d);
    const isToday = y === today.getFullYear() && mo === today.getMonth() && d === today.getDate();
    const isSel = selectedCalDay === dk;
    const isDone = !!completed[dk];
    const date = new Date(y, mo, d);
    const isPast = date <= today;

    if (wt !== 'R') sess++;
    if (wt !== 'R' && isDone) done++;
    if (isPast && wt !== 'R' && isDone) streak++;

    let cls = 'dc' + (isToday ? ' today' : '') + (isSel ? ' sel' : '');
    const pillCls = wt === 'R' ? 'pr' : WORKOUTS[wt].pill;
    const pillLbl = wt === 'R' ? 'Rest' : 'Day ' + wt;
    const focusTxt = wt === 'A' ? 'Power' : wt === 'B' ? 'Speed' : wt === 'C' ? 'Cond.' : '';

    html += `<div class="${cls}" onclick="calSelect('${dk}',${d})" id="dc-${dk}">
      <div class="dn">${d}</div>
      <div class="dpill ${pillCls}">${pillLbl}</div>
      ${wt !== 'R' ? `<div class="dfocus">${focusTxt}</div>` : ''}
      ${isDone ? `<div class="dcheck"><div class="dtick"></div></div>` : ''}
    </div>`;
  }

  const trailing = (firstDay + dim) % 7 === 0 ? 0 : 7 - (firstDay + dim) % 7;
  for (let i = 0; i < trailing; i++) html += `<div class="dc empty"></div>`;
  document.getElementById('calGrid').innerHTML = html;

  document.getElementById('sSess').textContent = sess;
  document.getElementById('sDone').textContent = done;
  document.getElementById('sHrs').textContent = done + 'h';
  document.getElementById('sStr').textContent = streak + 'd';
}

function calSelect(dk, d) {
  selectedCalDay = dk;
  const parts = dk.split('-');
  const y = parseInt(parts[0]), mo = parseInt(parts[1]);
  const wt = getWorkoutForDate(y, mo, d);
  const isDone = !!completed[dk];
  const dateStr = MONTHS[mo] + ' ' + d + ', ' + y;

  let html = `<div class="detail-panel">
    <div class="dp-hd">
      <div>
        <div class="dp-sub">${dateStr}</div>
        <div class="dp-title">${wt === 'R' ? 'Rest day' : 'Day ' + wt + ' – ' + (wt === 'A' ? 'Power' : wt === 'B' ? 'Speed' : 'Conditioning')}</div>
      </div>
      <div class="dp-actions">`;

  if (wt !== 'R') {
    html += `<button class="mkbtn${isDone ? ' done' : ''}" onclick="toggleDone('${dk}')">${isDone ? 'Completed' : 'Mark done'}</button>
      <button class="stbtn" onclick="launchTimer('${wt}')">Start</button>`;
  }

  html += `</div></div>`;

  if (wt === 'R') {
    html += `<div style="font-size:13px;color:var(--text-secondary)">Active recovery day. Light walk, mobility work, or full rest.</div>`;
  } else {
    const wo = WORKOUTS[wt];
    let lastPh = null;
    html += `<div>`;
    wo.exercises.forEach(ex => {
      const ph = ex.phase;
      if (ph !== 'rest' && ph !== lastPh) { html += `<div class="ph-lbl">${PHASE_META[ph].label}</div>`; lastPh = ph; }
      if (ph === 'rest') return;
      const rnd = ex.rounds > 1 ? `${ex.rounds}×${fmt(ex.secs)}` : fmt(ex.secs);
      html += `<div class="exrow">
        <div class="ephase ${PHASE_META[ph].cls}">${PHASE_META[ph].label.slice(0, 4)}</div>
        <div style="flex:1;font-size:12px;color:var(--text-primary)">${ex.name}</div>
        <div class="edur">${rnd}</div>
      </div>`;
    });
    html += `</div><div style="margin-top:.5rem;font-size:11px;color:var(--text-tertiary)">60 min · 3 boxing rounds · punch sounds + combo timer</div>`;
  }

  html += `</div>`;
  const panel = document.getElementById('calDetail');
  panel.innerHTML = html;
  panel.style.display = 'block';
  buildCalendar();
  panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function toggleDone(dk) {
  if (completed[dk]) delete completed[dk]; else completed[dk] = true;
  buildCalendar();
  const parts = dk.split('-');
  calSelect(dk, parseInt(parts[2]));
}

function launchTimer(wt) {
  showView('timer');
  switchTimerDay(wt);
}

function shiftMonth(d) {
  viewMonth += d;
  if (viewMonth > 11) { viewMonth = 0; viewYear++; }
  if (viewMonth < 0) { viewMonth = 11; viewYear--; }
  selectedCalDay = null;
  document.getElementById('calDetail').style.display = 'none';
  buildCalendar();
}

/* ── TIMER ── */
function buildTimerTabs() {
  document.getElementById('dayTabsT').innerHTML = ['A', 'B', 'C'].map(d =>
    `<button class="dt${d === tActiveDay ? ' active' : ''}" onclick="switchTimerDay('${d}')">${WORKOUTS[d].label}</button>`
  ).join('');
}

function switchTimerDay(d) {
  stopTimer(); tActiveDay = d; tActiveEx = 0; tRound = 1;
  buildTimerTabs(); renderExList(); loadEx();
}

function renderExList() {
  const wo = WORKOUTS[tActiveDay];
  let html = '', lastPh = null, open = false;
  wo.exercises.forEach((ex, i) => {
    if (ex.phase === 'rest') { if (open) { html += '</div>'; open = false; } lastPh = null; return; }
    if (ex.phase !== lastPh) {
      if (open) html += '</div>';
      html += `<div class="ph-lbl">${PHASE_META[ex.phase].label}</div><div class="ex-list-t">`;
      open = true; lastPh = ex.phase;
    }
    const rnd = ex.rounds > 1 ? `${ex.rounds}×${fmt(ex.secs)}` : fmt(ex.secs);
    html += `<div class="exrow-t${i === tActiveEx ? ' aex' : ''}" id="et${i}" onclick="jumpToEx(${i})">
      <div class="exdot" style="background:${PHASE_META[ex.phase].color}"></div>
      <div class="exname">${ex.name}</div>
      ${ex.detail ? `<div class="exdet">${ex.detail}</div>` : ''}
      <div class="exdur2">${rnd}</div>
    </div>`;
  });
  if (open) html += '</div>';
  document.getElementById('exListT').innerHTML = html;
}

function loadEx() {
  const ex = WORKOUTS[tActiveDay].exercises[tActiveEx];
  tRemaining = ex.secs;
  document.getElementById('timeBig').textContent = fmt(tRemaining);
  document.getElementById('ringFg').style.strokeDashoffset = CIRC;
  document.getElementById('ringFg').style.stroke = PHASE_META[ex.phase].color;
  document.getElementById('tcName').textContent = ex.name;
  const b = document.getElementById('tcBadge');
  b.className = 'tc-badge eph-' + ex.phase;
  b.textContent = PHASE_META[ex.phase].label;
  document.getElementById('rndInfo').textContent = ex.rounds > 1 ? `Round 1 of ${ex.rounds}` : (ex.detail || '');
  updateNextUp(); updateProg();
  if (ex.phase === 'boxing') {
    currentCombo = COMBOS[Math.floor(Math.random() * COMBOS.length)];
    renderChips(currentCombo, -1);
    document.getElementById('comboBox').style.display = 'block';
  } else {
    document.getElementById('comboBox').style.display = 'none';
  }
  document.querySelectorAll('.exrow-t').forEach((r, i) => r.classList.toggle('aex', i === tActiveEx));
  const row = document.getElementById('et' + tActiveEx);
  if (row) row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

function renderChips(combo, activeIdx) {
  if (!combo) { document.getElementById('comboBox').style.display = 'none'; return; }
  document.getElementById('comboName').textContent = combo.name;
  document.getElementById('comboChips').innerHTML = combo.punches.map((p, i) => {
    const pd = PUNCH_DATA[p];
    return `<div class="pchip ${pd.chip}${i === activeIdx ? ' lit' : ''}">${pd.label}</div>`;
  }).join('');
  document.getElementById('callout').textContent = activeIdx >= 0 ? PUNCH_DATA[combo.punches[activeIdx]].word : '';
}

function fireCombo(combo) {
  clearSeq();
  let delay = 600;
  combo.punches.forEach((p, i) => {
    setTimeout(() => {
      if (!tRunning) return;
      playPunch(p);
      renderChips(combo, i);
    }, delay);
    delay += 380;
  });
  comboSeqId = setTimeout(() => {
    if (!tRunning) return;
    currentCombo = COMBOS[Math.floor(Math.random() * COMBOS.length)];
    renderChips(currentCombo, -1);
    setTimeout(() => { if (tRunning) fireCombo(currentCombo); }, 600);
  }, delay + 800);
}

function clearSeq() {
  if (comboSeqId) { clearTimeout(comboSeqId); comboSeqId = null; }
}

function toggleTimer() {
  ensureAudio();
  if (tRunning) { stopTimer(); return; }
  tRunning = true;
  document.getElementById('startBtn').textContent = 'Pause';
  const ex = WORKOUTS[tActiveDay].exercises[tActiveEx];
  if (ex.phase === 'boxing') fireCombo(currentCombo);
  tInterval = setInterval(() => {
    tRemaining--;
    document.getElementById('timeBig').textContent = fmt(tRemaining);
    const pct = tRemaining / ex.secs;
    document.getElementById('ringFg').style.strokeDashoffset = CIRC * (1 - pct);
    if (tRemaining <= 3 && tRemaining > 0) playWhistle();
    if (tRemaining <= 0) {
      playBell(); clearSeq(); renderChips(null, -1);
      if (ex.rounds > 1 && tRound < ex.rounds) {
        tRound++; tRemaining = ex.secs;
        document.getElementById('rndInfo').textContent = `Round ${tRound} of ${ex.rounds}`;
        if (ex.phase === 'boxing') {
          currentCombo = COMBOS[Math.floor(Math.random() * COMBOS.length)];
          renderChips(currentCombo, -1);
          setTimeout(() => { if (tRunning) fireCombo(currentCombo); }, 400);
        }
      } else {
        tRound = 1;
        const wo = WORKOUTS[tActiveDay];
        if (tActiveEx < wo.exercises.length - 1) {
          tActiveEx++; renderExList(); loadEx();
          const nex = wo.exercises[tActiveEx];
          if (nex.phase === 'boxing') setTimeout(() => { if (tRunning) fireCombo(currentCombo); }, 400);
        } else {
          stopTimer();
          document.getElementById('tcName').textContent = 'Session complete!';
          document.getElementById('rndInfo').textContent = 'Great work, fighter!';
          document.getElementById('progFill').style.width = '100%';
          document.getElementById('progPct').textContent = '100%';
        }
      }
    }
  }, 1000);
}

function stopTimer() {
  tRunning = false; clearInterval(tInterval); clearSeq();
  document.getElementById('startBtn').textContent = 'Start';
}

function jumpToEx(i) { stopTimer(); tActiveEx = i; tRound = 1; loadEx(); }
function prevEx() { stopTimer(); tRound = 1; if (tActiveEx > 0) { tActiveEx--; renderExList(); loadEx(); } }
function nextEx() { stopTimer(); tRound = 1; const wo = WORKOUTS[tActiveDay]; if (tActiveEx < wo.exercises.length - 1) { tActiveEx++; renderExList(); loadEx(); } }

function updateNextUp() {
  const wo = WORKOUTS[tActiveDay], el = document.getElementById('nextUp');
  el.innerHTML = tActiveEx < wo.exercises.length - 1
    ? `Next: <span>${wo.exercises[tActiveEx + 1].name}</span>`
    : '<span>Final exercise!</span>';
}

function updateProg() {
  const total = WORKOUTS[tActiveDay].exercises.length;
  const pct = Math.round((tActiveEx / total) * 100);
  document.getElementById('progFill').style.width = pct + '%';
  document.getElementById('progPct').textContent = pct + '%';
}

/* ── SETTINGS ── */
function buildSettings() {
  const grid = document.getElementById('dayAssignGrid');
  grid.innerHTML = DNAMES.map((dn, i) => {
    const cur = getAssignedType(i);
    const opts = ['R', 'A', 'B', 'C'].map(v =>
      `<option value="${v}"${cur === v ? ' selected' : ''}>${v === 'R' ? 'Rest' : 'Day ' + v}</option>`
    ).join('');
    return `<div class="day-col">
      <div class="day-col-name">${dn}</div>
      <select class="day-sel" id="ds${i}" onchange="previewSchedule()">${opts}</select>
    </div>`;
  }).join('');
  previewSchedule();
  buildOrderRow();
}

function getAssignedType(dow) {
  const idx = workoutDays.indexOf(dow);
  if (idx === -1) return 'R';
  return dayOrder[idx] || 'R';
}

function previewSchedule() {
  const picks = DNAMES.map((_, i) => (document.getElementById('ds' + i) || {}).value || 'R');
  const styles = {
    A: { bg: '#FCEBEB', c: '#791F1F' },
    B: { bg: '#E6F1FB', c: '#0C447C' },
    C: { bg: '#EAF3DE', c: '#27500A' },
    R: { bg: 'var(--bg-secondary)', c: 'var(--text-tertiary)' },
  };
  document.getElementById('weekPreview').innerHTML = DNAMES.map((dn, i) => {
    const v = picks[i]; const s = styles[v];
    return `<div class="wp-cell" style="background:${s.bg};color:${s.c}">${v === 'R' ? '–' : v}</div>`;
  }).join('');
}

function buildOrderRow() {
  document.getElementById('orderRow').innerHTML = dayOrder.map((d, i) =>
    `<div class="order-chip">Day ${d}</div>${i < dayOrder.length - 1 ? '<span class="order-arrow">→</span>' : ''}`
  ).join('');
}

function saveSchedule() {
  const picks = DNAMES.map((_, i) => ({ dow: i, val: (document.getElementById('ds' + i) || {}).value || 'R' }));
  const training = picks.filter(p => p.val !== 'R');
  if (training.length === 0) { alert('Pick at least 1 training day.'); return; }
  workoutDays = training.map(p => p.dow);
  const assigned = training.map(p => p.val);
  const order = [];
  ['A', 'B', 'C'].forEach(t => { if (assigned.includes(t)) order.push(t); });
  dayOrder = order.length > 0 ? order : ['A', 'B', 'C'];
  selectedCalDay = null;
  document.getElementById('calDetail').style.display = 'none';
  buildCalendar();
  buildSettings();
  showView('calendar');
}

/* ── INIT ── */
buildCalendar();
buildTimerTabs();
renderExList();
loadEx();
